Configuration CustomWebsite
{
param($MachineName)
Import-DscResource -ModuleName PSDesiredStateConfiguration    

Node localhost
{

File DemoFile
{
DestinationPath = 'C:\WindowsAzure\Logs\index.html'
Ensure = 'Present'
Type = 'File'
Contents = "<h2>The page from $($MachineName)</h2>"
Force = $true
}

WindowsFeature IIS
{
Ensure = 'Present'
Name = 'Web-Server'
}

WindowsFeature IISManagement
{
Ensure = 'Present'
Name = 'Web-Mgmt-Tools'
}

WindowsFeature AspNet45
{
Ensure = 'Present'
Name = 'Web-Asp-Net45'
}

File WebContent
{
Ensure = 'Present'
SourcePath = "C:\WindowsAzure\Logs\index.html"
DestinationPath = "C:\inetpub\wwwroot"
DependsOn = "[WindowsFeature]AspNet45"
}

}
}
